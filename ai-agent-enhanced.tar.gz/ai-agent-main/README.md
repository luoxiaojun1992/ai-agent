# AI Agent

## How to use (follow console instructions)

### Quick Start
```shell
make run
```

### Help
```shell
make help
```
